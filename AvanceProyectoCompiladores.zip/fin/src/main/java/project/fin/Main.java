
package project.fin;
import java.io.IOException;

import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;



public class Main {

	private static final String EXTENSION = "proj";

	public static void main(String[] args) throws IOException {
		String program = args.length > 1 ? args[1] : "test/test." + EXTENSION;

		System.out.println("Interpreting file " + program);

		proyectoFInalLexer lexer = new proyectoFInalLexer(new ANTLRFileStream(program));
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		proyectoFInalParser parser = new proyectoFInalParser(tokens);

		proyectoFInalParser.ProgramContext tree = parser.program();

		proyectoFInalCustomVisitor visitor = new proyectoFInalCustomVisitor();
		visitor.visit(tree);

		System.out.println("Interpretation finished");

	}

}
